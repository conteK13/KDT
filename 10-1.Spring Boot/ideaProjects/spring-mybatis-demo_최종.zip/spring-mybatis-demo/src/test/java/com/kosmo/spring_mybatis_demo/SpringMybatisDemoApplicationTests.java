package com.kosmo.spring_mybatis_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMybatisDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
