package com.kosmo.spring_mybatis_demo.basic.ioc.ex02;

public interface Service {
    void info();
}
