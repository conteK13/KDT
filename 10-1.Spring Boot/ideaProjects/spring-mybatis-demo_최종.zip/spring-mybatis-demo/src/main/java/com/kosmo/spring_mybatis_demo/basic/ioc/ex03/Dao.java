package com.kosmo.spring_mybatis_demo.basic.ioc.ex03;

public interface Dao {

    String daoInfo();
}
