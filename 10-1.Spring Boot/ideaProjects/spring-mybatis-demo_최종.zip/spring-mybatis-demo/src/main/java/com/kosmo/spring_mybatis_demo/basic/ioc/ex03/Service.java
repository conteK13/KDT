package com.kosmo.spring_mybatis_demo.basic.ioc.ex03;

public interface Service {
    void info1();
    void info2();

}
